All data in this package is published under a creative commons license: Attribution-NonCommercial-ShareAlike 3.0 Unported (CC BY-NC-SA 3.0) http://creativecommons.org/licenses/by-nc-sa/3.0/

If you're using (parts of) this data, please cite the corresponding publication:
Albrecht Lindner, Bryan Zhi Li, Nicolas Bonnier, and Sabine Süsstrunk, “A large-scale multi-lingual color thesaurus,” IS&T Color and Imaging Conference, 2012.

For any questions contact the author: AlbrechtJLindner@gmail.com   http://ivrg.epfl.ch/people/lindner
